package co.edu.uniquindio.poo;

import javax.swing.JOptionPane;

public class FabricaDeBusetas implements VehiculoDeTransporte{

	@Override
	public Vehiculo crearVehiculo() {
		Buseta miBuseta=new Buseta();
		miBuseta.setCodigo(miBuseta.generarCodigo());
		JOptionPane.showMessageDialog(null, "Se ha creado un nuevo Objeto Buseta  ");
		return miBuseta;
	}
}
