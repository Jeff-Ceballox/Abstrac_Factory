package co.edu.uniquindio.poo;

import javax.swing.JOptionPane;

public class FabricaDeBuses implements VehiculoDeTransporte {
    	public Vehiculo crearVehiculo() {

		Bus miBus=new Bus();
		miBus.setCodigo(miBus.generarCodigo());
		JOptionPane.showMessageDialog(null, "Se ha creado un nuevo Objeto Bus  ");
		return miBus;
	}

}
