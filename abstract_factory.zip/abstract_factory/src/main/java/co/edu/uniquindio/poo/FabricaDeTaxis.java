package co.edu.uniquindio.poo;

import javax.swing.JOptionPane;

public class FabricaDeTaxis implements VehiculoDeTransporte{
    
	@Override
	public Vehiculo crearVehiculo() {
		Taxi miTaxi=new Taxi();
		miTaxi.setCodigo(miTaxi.generarCodigo());
		JOptionPane.showMessageDialog(null, "Se ha creado un nuevo Objeto Taxi  ");
		return miTaxi;
	}

}
