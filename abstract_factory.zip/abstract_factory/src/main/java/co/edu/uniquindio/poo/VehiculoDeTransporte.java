package co.edu.uniquindio.poo;

public interface VehiculoDeTransporte {
	
	public Vehiculo crearVehiculo();

}