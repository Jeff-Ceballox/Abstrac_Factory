package co.edu.uniquindio.poo;

public interface Vehiculo {
	public void codigoDeVehiculo();
	public int generarCodigo();
    }
	