package co.edu.uniquindio.poo;

import javax.swing.JOptionPane;

public class AppTest {
    /**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		//Estas líneas crean instancias de las clases FabricaDeBusetas, FabricaDeTaxis y FabricaDeBuses
		// para poder utilizar sus métodos más adelante en el programa.
		FabricaDeBusetas busetas=new FabricaDeBusetas();
		FabricaDeTaxis taxi=new FabricaDeTaxis();
		FabricaDeBuses buses=new FabricaDeBuses();
		//Estas líneas declaran una cadena de caracteres cad que almacena el mensaje que se mostrará al usuario,
		// que incluye las opciones disponibles para obtener los códigos de servicio.
		String cad="",salida;
		cad+="Ingrese la opciòn correspondiente para crear \nel codigo del servicio\n\n";
		cad+="1. Codigo servicio de Taxis\n";
		cad+="2. Codigo servicio de Buses\n";
		cad+="3. Codigo servicio de Busetas\n\n";
		//Estas líneas inician un bucle do-while que permite al usuario ingresar opciones
		// y consultar los códigos de servicio de taxis, buses o busetas. El bucle continuará hasta que el usuario decida salir.

		//Se manejan excepciones para posibles errores en la entrada del usuario. Si ocurre alguna excepción,
		// se mostrará un mensaje de error adecuado.
		try {
			do {
				try 
				{
					int opcion=Integer.parseInt(JOptionPane.showInputDialog(cad));
					
					switch (opcion)
					{
					case 1: FabricaDeVehiculos.crearFabricaDeVehiculo(taxi);
						break;
					case 2: FabricaDeVehiculos.crearFabricaDeVehiculo(buses);
						break;
					case 3: FabricaDeVehiculos.crearFabricaDeVehiculo(busetas);
						break;
					default: JOptionPane.showMessageDialog(null,"No es un valor de consulta valido");
						break;
						}
				} catch (Exception e) {
						JOptionPane.showMessageDialog(null,"No es un parametro de consulta valido");
					}
			salida=JOptionPane.showInputDialog("Desea consultar otro codigo? S/N");
			
			} while (salida.toUpperCase().equals("S"));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"No hay mas busquedas");
		}	
	}
}